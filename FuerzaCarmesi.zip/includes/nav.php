<nav id="main-menu">
    <div class="fondo menu">
        <div class="borde-juego">
            <ul >
                <li><a href="index.php">Inicio</a></li>
                <li><a href="story.php">Historia</a></li>
                <li><a href="characters.php">Personajes</a></li>
                <li><a href="world.php">Mundo</a></li>
                <li><a href="gallery.php">Galer&iacute;a</a></li>
                <li><a href="tips.php">Tips</a></li>
            </ul>
        </div>
    </div>
    <div class="fila">
        <div class="noticias-titulo borde-juego fondo">Noticias</div>
        <div id="scrolling" class="noticias borde-noticias">
            <ul>
                <li><strong>10 de octubre de 2023</strong><br>¡Publicado el sitio web oficial de Fuerza Carmesí!</li>
                <li><strong>11 de diciembre de 2023</strong><br>Añadida información de los personajes e historia.</li>
                <li><strong>11 de diciembre de 2023</strong><br>Añadidos tips e información sobre el mundo.</li>
                <li><strong>11 de diciembre de 2023</strong><br>¡Subido Trailer oficial de Fuerza Carmesí!</li>
            </ul>
        </div>
    </div>
</nav>