<div class="pagina">
    <header>
        <a class="logo" href="index.php"></a>
    </header>