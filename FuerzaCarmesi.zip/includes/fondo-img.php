<div class="fondo-imagen">
    <div class="back-stars"></div>
    <div class="himalia">
        <div class="back-sky"></div>
        <div class="back-clouds"></div>
        <div class="back-plains"></div>
        <div class="back-forest"></div>
    </div>
</div>